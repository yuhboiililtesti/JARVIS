# J.A.R.V.I.S V7

This build keeps the modern dashboard, improves voice delivery, and replaces the blocked chess iframe with a local chess board and local engine.

## Highlights
- Ollama chat
- natural-language system routing
- proactive monitoring
- browser microphone fallback
- full spoken replies at a faster rate
- local chess board and local chess engine
- modern dashboard with live backend panels

## Quick start
```powershell
python -m pip install -r requirements.txt
ollama serve
python run_ui.py
```

Open:
`http://127.0.0.1:8000`

## CLI
```powershell
python main.py
```

## Notes
- Local Python mic input remains optional.
- If Python mic is unavailable, use the Browser mic button in the dashboard.
- Chess is now local and no longer depends on an embedded external site.
