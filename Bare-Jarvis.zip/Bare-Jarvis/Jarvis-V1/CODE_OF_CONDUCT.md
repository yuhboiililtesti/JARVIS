# Code of Conduct

## Our Standard
Participants are expected to be respectful, direct, and constructive.

## Unacceptable Behavior
- Harassment or intimidation
- Doxxing or disclosure of private information
- Malicious code, exploit payloads, or deceptive contributions
- Misrepresenting prototype code as production-ready

## Enforcement
Project maintainers may remove comments, reject changes, or block contributors who violate these standards.
