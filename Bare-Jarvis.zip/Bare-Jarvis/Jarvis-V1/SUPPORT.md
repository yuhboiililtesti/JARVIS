# Support

## Before opening an issue
1. Read the README
2. Run the documented setup steps
3. Check whether Ollama is running if AI features fail
4. Note your OS, Python version, and the exact command you ran

## Include in bug reports
- operating system
- Python version
- install command
- startup command
- full traceback or logs
- whether voice features were enabled
