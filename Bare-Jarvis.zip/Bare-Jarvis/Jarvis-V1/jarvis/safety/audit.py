from __future__ import annotations

import sqlite3
from jarvis.constants import DB_PATH

def log_audit(category: str, message: str) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO audit_log (category, message) VALUES (?, ?)",
        (category, message),
    )
    conn.commit()
    conn.close()

def get_recent_audit(limit: int = 100) -> list[dict]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT category, message, created_at FROM audit_log ORDER BY id DESC LIMIT ?",
        (limit,),
    )
    rows = cur.fetchall()
    conn.close()
    return [
        {"category": r[0], "message": r[1], "created_at": r[2]}
        for r in rows
    ]
