from __future__ import annotations

ALLOW_MUTATING_REPAIRS = False

BLOCKED_PHRASES = {
    "format drive",
    "delete system32",
    "shutdown -s",
    "rm -rf /",
    "mkfs",
}

def is_prompt_blocked(text: str) -> bool:
    normalized = text.lower()
    return any(phrase in normalized for phrase in BLOCKED_PHRASES)
