from __future__ import annotations

import sqlite3
from jarvis.constants import DB_PATH

def update_score(action: str, success: bool) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT score, success_count, failure_count FROM learning WHERE action = ?", (action,))
    row = cur.fetchone()

    delta = 1 if success else -1
    if row:
        score, success_count, failure_count = row
        success_count = success_count + (1 if success else 0)
        failure_count = failure_count + (0 if success else 1)
        cur.execute(
            """
            UPDATE learning
            SET score = ?, success_count = ?, failure_count = ?, updated_at = CURRENT_TIMESTAMP
            WHERE action = ?
            """,
            (score + delta, success_count, failure_count, action),
        )
    else:
        cur.execute(
            "INSERT INTO learning (action, score, success_count, failure_count) VALUES (?, ?, ?, ?)",
            (action, delta, 1 if success else 0, 0 if success else 1),
        )
    conn.commit()
    conn.close()

def get_top_actions(limit: int = 10) -> list[dict]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT action, score, success_count, failure_count, updated_at FROM learning ORDER BY score DESC, success_count DESC LIMIT ?",
        (limit,),
    )
    rows = cur.fetchall()
    conn.close()
    return [
        {
            "action": r[0],
            "score": r[1],
            "success_count": r[2],
            "failure_count": r[3],
            "updated_at": r[4],
        }
        for r in rows
    ]
