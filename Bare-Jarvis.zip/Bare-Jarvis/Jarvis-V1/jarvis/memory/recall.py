from __future__ import annotations

import sqlite3
from jarvis.constants import DB_PATH

def get_recent(limit: int = 8) -> list[tuple[str, str]]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT role, content FROM memory ORDER BY id DESC LIMIT ?",
        (limit,),
    )
    rows = cur.fetchall()
    conn.close()
    return list(reversed(rows))

def build_context(limit: int = 8) -> str:
    rows = get_recent(limit)
    return "\n".join(f"{role.upper()}: {content}" for role, content in rows)
