from __future__ import annotations

import sqlite3
from jarvis.constants import DB_PATH

def save_message(role: str, content: str) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO memory (role, content) VALUES (?, ?)",
        (role, content),
    )
    conn.commit()
    conn.close()
