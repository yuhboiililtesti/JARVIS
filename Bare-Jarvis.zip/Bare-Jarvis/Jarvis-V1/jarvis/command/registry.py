from __future__ import annotations

from jarvis.command.handlers import handle_system_status, handle_repair

COMMANDS = {
    "system status": handle_system_status,
    "analyze system": handle_system_status,
    "repair system": handle_repair,
    "fix system": handle_repair,
}

def match_command(text: str):
    normalized = text.strip().lower()
    return COMMANDS.get(normalized)
