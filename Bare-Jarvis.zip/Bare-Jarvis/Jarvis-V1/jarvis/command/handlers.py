from __future__ import annotations

from providers.system.analyzer import analyze_system
from providers.system.repair import perform_safe_repairs
from providers.system.processes import top_processes_by_memory
from jarvis.monitoring.alerts import get_active_alerts

def handle_system_status(_: str) -> str:
    report = analyze_system()
    ram = report["memory"]["ram_percent"]
    cpu = report["cpu"]["usage_percent"]
    disk = report["disk_health"]["usage_percent"]

    if report["risk"] == "high":
        lead = "System health is strained right now."
    elif report["risk"] == "medium":
        lead = "System is stable, but a few things need attention."
    else:
        lead = "System looks healthy overall."

    findings = " ".join(report["findings"]) if report["findings"] else "No urgent findings."
    return (
        f"{lead} CPU is at {cpu} percent, memory is at {ram} percent, "
        f"and disk usage is {disk} percent. {findings}"
    )

def handle_repair(_: str) -> str:
    result = perform_safe_repairs()
    suggestions = result["suggestions"]
    if suggestions == ["No urgent repair actions suggested."]:
        return "I do not see anything urgent to fix right now."
    return "Here is what I would do first: " + " ".join(suggestions)

def handle_process_summary(_: str) -> str:
    procs = top_processes_by_memory(5)
    if not procs:
        return "I could not identify any heavy processes right now."
    top = procs[0]
    names = ", ".join(f"{p['name']} ({p['memory_percent']}%)" for p in procs)
    return (
        f"The heaviest memory user right now is {top['name']} at {top['memory_percent']} percent. "
        f"Top processes: {names}."
    )

def handle_alert_summary(_: str) -> str:
    alerts = get_active_alerts(5)
    if not alerts:
        return "There are no active alerts right now."
    first = alerts[0]
    more = len(alerts) - 1
    suffix = f" There are {more} more active alerts." if more > 0 else ""
    return f"Current alert: {first['title']}. {first['details']}.{suffix}"
