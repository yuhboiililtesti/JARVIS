from __future__ import annotations

from jarvis.config import load_config
from jarvis.memory.store import save_message
from jarvis.memory.recall import build_context
from jarvis.brain.router import route_input
from jarvis.adaptive.scoring import update_score
from jarvis.safety.policy import is_prompt_blocked
from jarvis.safety.audit import log_audit
from providers.ollama.client import OllamaClient

_SYSTEM_PROMPT = (
    "You are J.A.R.V.I.S, a system-aware local AI assistant. "
    "Speak naturally, briefly, and confidently. "
    "Do not sound like a generic chatbot. "
    "When the user asks about system health, performance, or issues, answer as if you are aware of the machine state. "
    "Prefer direct wording. Avoid filler and avoid repeating the user's request."
)

class Agent:
    def __init__(self) -> None:
        cfg = load_config()
        self.client = OllamaClient(
            base_url=cfg["ollama"]["base_url"],
            model=cfg["ollama"]["model"],
        )

    def run(self, user_input: str) -> str:
        if is_prompt_blocked(user_input):
            log_audit("policy", f"Blocked prompt: {user_input}")
            update_score("blocked_prompt", True)
            return "Request blocked by local safety policy."

        decision = route_input(user_input)
        save_message("user", user_input)

        if decision["type"] in {"intent", "automation"}:
            try:
                result = decision["handler"](user_input)
                update_score(decision["type"], True)
                save_message("assistant", result)
                return result
            except Exception as exc:
                update_score(decision["type"], False)
                log_audit("handler_error", str(exc))
                raise

        context = build_context(limit=8)
        prompt = f"{context}\nUSER: {user_input}\nASSISTANT:"
        try:
            result = self.client.generate(prompt=prompt, system=_SYSTEM_PROMPT)
            update_score("ollama_response", True)
        except Exception as exc:
            update_score("ollama_response", False)
            log_audit("ollama_error", str(exc))
            result = (
                "Ollama request failed. Start Ollama and ensure the configured model is installed. "
                f"Error: {exc}"
            )

        save_message("assistant", result)
        return result
