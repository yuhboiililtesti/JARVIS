from __future__ import annotations

from jarvis.command.handlers import (
    handle_system_status,
    handle_repair,
    handle_process_summary,
    handle_alert_summary,
)
from jarvis.automation.engine import match_automation

SYSTEM_STATUS_PATTERNS = [
    "how is the system",
    "how's the system",
    "hows the system",
    "is the system okay",
    "system health",
    "system status",
    "check the system",
    "how are things running",
    "how is my pc",
    "how is the computer",
    "how is everything running",
]

REPAIR_PATTERNS = [
    "fix the system",
    "repair the system",
    "optimize the system",
    "clean things up",
    "help performance",
    "make it faster",
]

PROCESS_PATTERNS = [
    "what is using memory",
    "what's using memory",
    "top memory processes",
    "what is slowing the system",
    "what's slowing the system",
    "show heavy processes",
]

ALERT_PATTERNS = [
    "any alerts",
    "anything wrong",
    "what should i worry about",
    "what needs attention",
]

def _contains_any(text: str, patterns: list[str]) -> bool:
    return any(p in text for p in patterns)

def route_input(text: str) -> dict:
    normalized = text.strip().lower()

    if _contains_any(normalized, SYSTEM_STATUS_PATTERNS):
        return {"type": "intent", "handler": handle_system_status}

    if _contains_any(normalized, REPAIR_PATTERNS):
        return {"type": "intent", "handler": handle_repair}

    if _contains_any(normalized, PROCESS_PATTERNS):
        return {"type": "intent", "handler": handle_process_summary}

    if _contains_any(normalized, ALERT_PATTERNS):
        return {"type": "intent", "handler": handle_alert_summary}

    automation = match_automation(normalized)
    if automation:
        return {"type": "automation", "handler": automation}

    return {"type": "llm", "handler": None}
