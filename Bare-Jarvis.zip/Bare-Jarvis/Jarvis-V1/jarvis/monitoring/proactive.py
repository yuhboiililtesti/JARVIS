from __future__ import annotations

import threading
import time
from providers.system.analyzer import analyze_system
from jarvis.monitoring.alerts import add_alert, clear_alerts_by_title
from jarvis.safety.audit import log_audit

MEMORY_ALERT = "High memory usage"
CPU_ALERT = "High CPU usage"
DISK_ALERT = "Low disk headroom"

def evaluate_system() -> None:
    report = analyze_system()

    ram = report["memory"]["ram_percent"]
    cpu = report["cpu"]["usage_percent"]
    disk = report["disk_health"]["usage_percent"]

    if ram >= 85:
        add_alert("warning" if ram < 92 else "critical", MEMORY_ALERT, f"RAM usage is {ram} percent.")
        log_audit("monitor", f"Memory alert triggered at {ram}%")
    else:
        clear_alerts_by_title(MEMORY_ALERT)

    if cpu >= 85:
        add_alert("warning" if cpu < 95 else "critical", CPU_ALERT, f"CPU usage is {cpu} percent.")
        log_audit("monitor", f"CPU alert triggered at {cpu}%")
    else:
        clear_alerts_by_title(CPU_ALERT)

    if disk >= 90:
        add_alert("warning" if disk < 96 else "critical", DISK_ALERT, f"Disk usage is {disk} percent.")
        log_audit("monitor", f"Disk alert triggered at {disk}%")
    else:
        clear_alerts_by_title(DISK_ALERT)

def start_monitor(interval_seconds: int = 30) -> threading.Thread:
    def loop():
        while True:
            try:
                evaluate_system()
            except Exception as exc:
                log_audit("monitor_error", str(exc))
            time.sleep(interval_seconds)

    thread = threading.Thread(target=loop, daemon=True, name="jarvis-proactive-monitor")
    thread.start()
    return thread
