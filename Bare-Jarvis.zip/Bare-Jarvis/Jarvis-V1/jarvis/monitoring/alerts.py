from __future__ import annotations

import sqlite3
from jarvis.constants import DB_PATH

def init_alerts_table() -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            level TEXT NOT NULL,
            title TEXT NOT NULL,
            details TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def add_alert(level: str, title: str, details: str) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO alerts (level, title, details, is_active) VALUES (?, ?, ?, 1)",
        (level, title, details),
    )
    conn.commit()
    conn.close()

def clear_alerts_by_title(title: str) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("UPDATE alerts SET is_active = 0 WHERE title = ? AND is_active = 1", (title,))
    conn.commit()
    conn.close()

def get_active_alerts(limit: int = 20) -> list[dict]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT id, level, title, details, created_at FROM alerts WHERE is_active = 1 ORDER BY id DESC LIMIT ?",
        (limit,),
    )
    rows = cur.fetchall()
    conn.close()
    return [
        {
            "id": r[0],
            "level": r[1],
            "title": r[2],
            "details": r[3],
            "created_at": r[4],
        }
        for r in rows
    ]
