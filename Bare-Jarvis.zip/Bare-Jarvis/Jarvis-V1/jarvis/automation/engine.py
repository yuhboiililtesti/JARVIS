from __future__ import annotations

from jarvis.config import load_automation_config
from jarvis.automation.rules import ACTION_MAP
from jarvis.safety.audit import log_audit

def match_automation(text: str):
    text_lower = text.lower()
    cfg = load_automation_config()
    for rule in cfg.get("rules", []):
        trigger = rule.get("trigger_contains", "").lower()
        action_name = rule.get("action")
        if trigger and trigger in text_lower and action_name in ACTION_MAP:
            action = ACTION_MAP[action_name]
            def runner(user_text: str, _action=action, _rule_name=rule.get("name", action_name)):
                result = _action(user_text)
                log_audit("automation", f"Executed automation rule: {_rule_name}")
                return result
            return runner
    return None
