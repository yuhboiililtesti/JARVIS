from __future__ import annotations

from providers.system.repair import perform_safe_repairs

def system_health_check(_: str) -> str:
    result = perform_safe_repairs()
    risk = result["report"]["risk"]
    suggestions = "; ".join(result["suggestions"])
    return f"System risk: {risk}. Suggestions: {suggestions}"

ACTION_MAP = {
    "system_health_check": system_health_check,
}
