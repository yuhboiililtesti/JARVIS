from __future__ import annotations

import logging
from jarvis.constants import LOGS_DIR

LOGS_DIR.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger("jarvis")
logger.setLevel(logging.INFO)

if not logger.handlers:
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    file_handler = logging.FileHandler(LOGS_DIR / "jarvis.log", encoding="utf-8")
    file_handler.setFormatter(formatter)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
