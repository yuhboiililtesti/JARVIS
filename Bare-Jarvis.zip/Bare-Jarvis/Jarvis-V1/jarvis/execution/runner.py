from __future__ import annotations

from jarvis.execution.validator import validate_python
from jarvis.execution.sandbox import run_python_in_sandbox
from jarvis.safety.audit import log_audit

def execute_generated_code(code: str) -> dict:
    ok, reason = validate_python(code)
    if not ok:
        log_audit("sandbox", f"blocked generated code: {reason}")
        return {"ok": False, "reason": reason, "result": None}

    result = run_python_in_sandbox(code)
    log_audit("sandbox", f"executed generated code with return code {result['returncode']}")
    return {"ok": True, "reason": "executed", "result": result}
