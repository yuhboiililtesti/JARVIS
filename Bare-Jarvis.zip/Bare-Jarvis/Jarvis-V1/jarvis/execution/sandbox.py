from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

def run_python_in_sandbox(code: str, timeout: int = 5) -> dict:
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir) / "sandbox_task.py"
        tmp.write_text(code, encoding="utf-8")
        result = subprocess.run(
            [sys.executable, str(tmp)],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
