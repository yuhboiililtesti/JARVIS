from __future__ import annotations

from jarvis.bootstrap import init_db
from jarvis.logger import logger
from jarvis.state import STATE
from providers.ollama.health import check_ollama_health
from jarvis.brain.agent import Agent
from jarvis.monitoring.proactive import start_monitor
from voice.engine import VoiceEngine

_monitor_started = False

def boot() -> None:
    global _monitor_started
    init_db()
    ok, detail = check_ollama_health()
    STATE.ollama_ok = ok
    STATE.last_error = None if ok else detail
    if ok:
        logger.info("Boot complete. Ollama reachable.")
    else:
        logger.warning("Boot complete. Ollama not reachable: %s", detail)

    if not _monitor_started:
        start_monitor(30)
        _monitor_started = True
        logger.info("Proactive monitor started.")

    voice = VoiceEngine()
    vstatus = voice.status()
    if vstatus.mic_available:
        logger.info("Voice mic available. Preferred voice: %s", vstatus.preferred_voice)
    else:
        logger.warning("Voice mic unavailable: %s", vstatus.mic_reason)

def run_cli() -> None:
    voice = VoiceEngine()
    agent = Agent()
    print("J.A.R.V.I.S ONLINE")
    if not STATE.ollama_ok:
        print("Warning: Ollama is not reachable. Start Ollama before using freeform chat.")
    vstatus = voice.status()
    if not vstatus.mic_available:
        print("Voice input unavailable in local Python. The dashboard browser mic can still be used if your browser supports Web Speech.")
    print("Type 'exit' to quit.")
    while True:
        user = input("You: ").strip()
        if not user:
            continue
        if user.lower() in {"exit", "quit"}:
            print("J.A.R.V.I.S: Powering down.")
            break
        try:
            response = agent.run(user)
        except Exception as exc:
            logger.exception("Unhandled error")
            response = f"Runtime error: {exc}"
        print(f"J.A.R.V.I.S: {response}")
        voice.speak_short(response)
