from __future__ import annotations

import chess
from dataclasses import dataclass, asdict

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 20000,
}

@dataclass
class ChessState:
    fen: str
    turn: str
    status: str
    last_move: str | None
    legal_moves: list[str]

class JarvisChess:
    def __init__(self) -> None:
        self.board = chess.Board()
        self.last_move_san = None

    def reset(self) -> dict:
        self.board.reset()
        self.last_move_san = None
        return self.state()

    def evaluate(self, board: chess.Board) -> int:
        if board.is_checkmate():
            return -999999 if board.turn == chess.WHITE else 999999
        score = 0
        for square, piece in board.piece_map().items():
            value = PIECE_VALUES.get(piece.piece_type, 0)
            score += value if piece.color == chess.WHITE else -value
        # small mobility bonus
        score += len(list(board.legal_moves)) * (1 if board.turn == chess.WHITE else -1)
        return score

    def choose_move(self) -> chess.Move | None:
        legal = list(self.board.legal_moves)
        if not legal:
            return None

        best_move = None
        maximizing = self.board.turn == chess.WHITE
        best_score = -10**9 if maximizing else 10**9

        for move in legal:
            self.board.push(move)
            score = self.evaluate(self.board)
            self.board.pop()
            if maximizing and score > best_score:
                best_score = score
                best_move = move
            elif not maximizing and score < best_score:
                best_score = score
                best_move = move

        return best_move or legal[0]

    def push_uci(self, uci: str) -> dict:
        try:
            move = chess.Move.from_uci(uci)
        except Exception:
            return {"ok": False, "error": "Invalid move format."}

        if move not in self.board.legal_moves:
            return {"ok": False, "error": "Illegal move."}

        user_san = self.board.san(move)
        self.board.push(move)
        self.last_move_san = user_san

        engine_note = None
        if not self.board.is_game_over():
            engine_move = self.choose_move()
            if engine_move:
                engine_san = self.board.san(engine_move)
                self.board.push(engine_move)
                engine_note = engine_san
                self.last_move_san = engine_san

        state = self.state()
        state["user_move"] = user_san
        state["jarvis_move"] = engine_note
        return {"ok": True, "state": state}

    def state(self) -> dict:
        status = "active"
        if self.board.is_checkmate():
            status = "checkmate"
        elif self.board.is_stalemate():
            status = "stalemate"
        elif self.board.is_insufficient_material():
            status = "draw"
        elif self.board.is_check():
            status = "check"

        obj = ChessState(
            fen=self.board.fen(),
            turn="white" if self.board.turn == chess.WHITE else "black",
            status=status,
            last_move=self.last_move_san,
            legal_moves=[m.uci() for m in self.board.legal_moves],
        )
        return asdict(obj)

CHESS = JarvisChess()
