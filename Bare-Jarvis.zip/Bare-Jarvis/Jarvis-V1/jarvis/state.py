from __future__ import annotations

from dataclasses import dataclass, field
from time import time

@dataclass
class RuntimeState:
    booted_at: float = field(default_factory=time)
    ollama_ok: bool = False
    last_error: str | None = None

STATE = RuntimeState()
