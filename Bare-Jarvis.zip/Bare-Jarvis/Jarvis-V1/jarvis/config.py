from __future__ import annotations

import json
from pathlib import Path
from jarvis.constants import CONFIG_DIR

def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def load_config() -> dict:
    primary = CONFIG_DIR / "app.json"
    example = CONFIG_DIR / "app.example.json"
    if primary.exists():
        return _load_json(primary)
    return _load_json(example)

def load_automation_config() -> dict:
    return _load_json(CONFIG_DIR / "automation.json")

def load_models_config() -> dict:
    return _load_json(CONFIG_DIR / "models.json")
