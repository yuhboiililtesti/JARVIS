from __future__ import annotations

from jarvis.execution.validator import validate_python

def validate_generated_module(code: str) -> tuple[bool, str]:
    return validate_python(code)
