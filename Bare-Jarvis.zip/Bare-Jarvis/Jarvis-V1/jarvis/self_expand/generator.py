from __future__ import annotations

from jarvis.config import load_config, load_models_config
from providers.ollama.client import OllamaClient

def generate_module_code(task_description: str) -> str:
    cfg = load_config()
    models = load_models_config()
    client = OllamaClient(
        base_url=cfg["ollama"]["base_url"],
        model=models["module_generator_model"],
    )
    prompt = f'''
Write a single Python module for this task:
{task_description}

Rules:
- Return only Python code.
- No markdown fences.
- No filesystem writes.
- No subprocess.
- Keep it self-contained.
'''
    return client.generate(prompt, system="You generate safe, minimal Python modules.")
