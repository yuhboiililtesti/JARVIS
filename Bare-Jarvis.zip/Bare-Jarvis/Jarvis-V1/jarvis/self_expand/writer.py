from __future__ import annotations

from pathlib import Path
from jarvis.constants import GENERATED_DIR
from jarvis.safety.audit import log_audit

def save_generated_module(name: str, code: str) -> str:
    safe_name = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in name.strip().lower())
    if not safe_name:
        safe_name = "generated_module"
    path = GENERATED_DIR / f"{safe_name}.py"
    path.write_text(code, encoding="utf-8")
    log_audit("self_expand", f"Saved generated module: {path.name}")
    return str(path)
