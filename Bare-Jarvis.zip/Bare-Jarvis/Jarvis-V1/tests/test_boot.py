from jarvis.bootstrap import init_db
from jarvis.constants import DB_PATH

def test_init_db():
    init_db()
    assert DB_PATH.exists()
