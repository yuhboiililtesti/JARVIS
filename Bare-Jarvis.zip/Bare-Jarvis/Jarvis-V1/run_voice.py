from jarvis.runtime import boot
from voice.loop import run_voice_loop

if __name__ == "__main__":
    boot()
    run_voice_loop()
