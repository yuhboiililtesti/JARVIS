from fastapi import FastAPI
from api.routes.ask import router as ask_router
from jarvis.runtime import boot

boot()
app = FastAPI(title="J.A.R.V.I.S API")
app.include_router(ask_router, prefix="/api")
