from fastapi import APIRouter
from api.schemas.ask import AskRequest
from jarvis.brain.agent import Agent
from providers.system.analyzer import analyze_system
from providers.system.repair import perform_safe_repairs
from jarvis.adaptive.scoring import get_top_actions
from jarvis.safety.audit import get_recent_audit
from jarvis.monitoring.alerts import get_active_alerts
from voice.engine import VoiceEngine
from jarvis.games.chess_engine import CHESS

router = APIRouter()
agent = Agent()

@router.post("/ask")
def ask(req: AskRequest):
    return {"response": agent.run(req.prompt)}

@router.get("/metrics")
def metrics():
    return analyze_system()

@router.get("/repair")
def repair():
    return perform_safe_repairs()

@router.get("/learning")
def learning():
    return {"top_actions": get_top_actions()}

@router.get("/logs")
def logs():
    return {"audit": get_recent_audit(100)}

@router.get("/alerts")
def alerts():
    return {"alerts": get_active_alerts(20)}

@router.get("/voice-status")
def voice_status():
    status = VoiceEngine().status()
    return {
        "tts_available": status.tts_available,
        "mic_available": status.mic_available,
        "mic_reason": status.mic_reason,
        "preferred_voice": status.preferred_voice,
        "browser_mic_supported_hint": True,
    }

@router.get("/chess/state")
def chess_state():
    return CHESS.state()

@router.post("/chess/reset")
def chess_reset():
    return CHESS.reset()

@router.post("/chess/move")
def chess_move(payload: dict):
    move = payload.get("move", "")
    return CHESS.push_uci(move)
