from jarvis.bootstrap import init_db

if __name__ == "__main__":
    init_db()
    print("Bootstrap complete.")
