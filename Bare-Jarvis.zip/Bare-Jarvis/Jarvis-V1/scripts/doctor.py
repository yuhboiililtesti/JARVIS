from __future__ import annotations

import importlib
import shutil
from jarvis.bootstrap import init_db
from providers.ollama.health import check_ollama_health
from providers.system.analyzer import analyze_system
from voice.engine import VoiceEngine

def check_module(name: str) -> str:
    try:
        importlib.import_module(name)
        return "OK"
    except Exception as exc:
        return f"ERROR: {exc}"

if __name__ == "__main__":
    init_db()
    print("=== J.A.R.V.I.S Doctor ===")
    for mod in ["requests", "fastapi", "uvicorn", "psutil", "speech_recognition", "pyttsx3"]:
        print(f"module:{mod} -> {check_module(mod)}")

    for binary in ["python", "ollama"]:
        print(f"binary:{binary} -> {shutil.which(binary) or 'MISSING'}")

    ok, detail = check_ollama_health()
    print(f"ollama_health -> {'OK' if ok else 'ERROR'} ({detail})")

    voice = VoiceEngine().status()
    print(f"tts_available -> {voice.tts_available}")
    print(f"mic_available -> {voice.mic_available}")
    print(f"mic_reason -> {voice.mic_reason}")
    print(f"preferred_voice -> {voice.preferred_voice}")

    try:
        report = analyze_system()
        print(f"system_risk -> {report['risk']}")
        print(f"cpu -> {report['cpu']['usage_percent']}%")
        print(f"memory -> {report['memory']['ram_percent']}%")
        print(f"disk -> {report['disk_health']['usage_percent']}%")
    except Exception as exc:
        print(f"system_analysis -> ERROR ({exc})")
