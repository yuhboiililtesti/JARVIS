from jarvis.runtime import boot, run_cli

if __name__ == "__main__":
    boot()
    run_cli()
