# Contributing

## Scope
This repository is currently a prototype. Contributions should prioritize reliability, clear error handling, and honest documentation over feature inflation.

## Development setup
```bash
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\\Scripts\\activate   # Windows PowerShell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
pytest
```

## Branching
- Create a feature branch from `main`
- Keep pull requests focused
- Prefer one logical change per PR

## Coding standards
- Keep modules small and explicit
- Add docstrings for non-trivial functions
- Do not introduce placeholder code presented as complete
- Guard platform-specific features with clear fallbacks
- Do not hardcode secrets, usernames, or local paths

## Tests
- Add or update tests for behavior changes
- Do not merge code that breaks the existing test suite

## Documentation
Update the README and configuration examples when behavior changes.

## Security
Do not open pull requests containing API keys, tokens, local database files, logs, or private machine details.
