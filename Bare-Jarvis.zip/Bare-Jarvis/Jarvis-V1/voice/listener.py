from __future__ import annotations

import speech_recognition as sr

recognizer = sr.Recognizer()

def listen_once(timeout: int = 5, phrase_time_limit: int = 10) -> str:
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
    return recognizer.recognize_google(audio)
