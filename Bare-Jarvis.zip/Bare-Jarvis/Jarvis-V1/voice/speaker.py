from __future__ import annotations

import pyttsx3

_engine = pyttsx3.init()

def speak(text: str) -> None:
    _engine.say(text)
    _engine.runAndWait()
