def detect_wakeword(text: str, wakeword: str = "jarvis") -> bool:
    return wakeword.lower() in text.lower()
