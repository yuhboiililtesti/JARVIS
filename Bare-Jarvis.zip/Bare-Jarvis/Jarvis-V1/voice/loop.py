from __future__ import annotations

from jarvis.brain.agent import Agent
from jarvis.logger import logger
from voice.engine import VoiceEngine

def run_voice_loop() -> None:
    voice = VoiceEngine()
    status = voice.status()
    if not status.mic_available:
        logger.warning("Voice loop not started. Microphone backend unavailable: %s", status.mic_reason)
        return

    import speech_recognition as sr

    recognizer = sr.Recognizer()
    recognizer.pause_threshold = 0.8
    recognizer.dynamic_energy_threshold = True

    agent = Agent()
    logger.info("Voice loop started")
    while True:
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.4)
                audio = recognizer.listen(source, timeout=5, phrase_time_limit=8)

            text = recognizer.recognize_google(audio)
            if "jarvis" not in text.lower():
                continue

            voice.speak("Yes?")
            with sr.Microphone() as source:
                audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
            command = recognizer.recognize_google(audio)

            answer = agent.run(command)
            voice.speak_short(answer)

        except KeyboardInterrupt:
            logger.info("Voice loop stopped by user")
            break
        except sr.WaitTimeoutError:
            continue
        except Exception as exc:
            logger.warning("Voice loop error: %s", exc)
