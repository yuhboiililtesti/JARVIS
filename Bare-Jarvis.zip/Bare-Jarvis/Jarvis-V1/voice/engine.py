from __future__ import annotations

from dataclasses import dataclass

try:
    import pyttsx3
except Exception:  # pragma: no cover
    pyttsx3 = None

@dataclass
class VoiceStatus:
    tts_available: bool
    mic_available: bool
    mic_reason: str | None = None
    preferred_voice: str | None = None

class VoiceEngine:
    def __init__(self) -> None:
        self.engine = pyttsx3.init() if pyttsx3 else None
        self.selected_voice = None
        self._configure_voice()
        self._mic_checked = False
        self._mic_available = False
        self._mic_reason = None

    def _configure_voice(self) -> None:
        if not self.engine:
            return
        try:
            voices = self.engine.getProperty("voices")
            british = None
            fallback = None
            for voice in voices:
                voice_id = getattr(voice, "id", "") or ""
                voice_name = getattr(voice, "name", "") or ""
                low = f"{voice_id} {voice_name}".lower()
                if fallback is None:
                    fallback = voice
                if "en-gb" in low or "british" in low or "hazel" in low or "george" in low:
                    british = voice
                    break
            selected = british or fallback
            if selected:
                self.engine.setProperty("voice", selected.id)
                # faster, cleaner cadence
                self.engine.setProperty("rate", 212)
                self.engine.setProperty("volume", 1.0)
                self.selected_voice = getattr(selected, "name", None) or getattr(selected, "id", None)
        except Exception:
            self.selected_voice = None

    def speak(self, text: str) -> bool:
        if not self.engine:
            return False
        try:
            self.engine.stop()
            self.engine.say(text)
            self.engine.runAndWait()
            return True
        except Exception:
            return False

    def speak_short(self, text: str) -> bool:
        # Keep full response per user request, just clean spacing.
        compact = " ".join(text.split())
        return self.speak(compact)

    def _check_mic(self) -> None:
        if self._mic_checked:
            return
        self._mic_checked = True
        try:
            import speech_recognition as sr
            _ = sr.Microphone
            try:
                with sr.Microphone() as _source:
                    pass
                self._mic_available = True
                self._mic_reason = None
            except Exception as exc:
                self._mic_available = False
                self._mic_reason = str(exc)
        except Exception as exc:
            self._mic_available = False
            self._mic_reason = str(exc)

    def status(self) -> VoiceStatus:
        self._check_mic()
        return VoiceStatus(
            tts_available=self.engine is not None,
            mic_available=self._mic_available,
            mic_reason=self._mic_reason,
            preferred_voice=self.selected_voice,
        )
