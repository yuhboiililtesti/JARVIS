# GitHub-ready additions included

This bundle adds:
- `.gitignore`
- `LICENSE`
- sanitized `.env.example`
- sanitized `config/app.example.json`
- updated `README.md`
- `CONTRIBUTING.md`
- `CODE_OF_CONDUCT.md`
- `SECURITY.md`
- `SUPPORT.md`
- GitHub issue templates
- PR template
- GitHub Actions CI workflow
- publishing checklist
- `.editorconfig`

Local-only file removed from the public bundle:
- `config/app.json`
