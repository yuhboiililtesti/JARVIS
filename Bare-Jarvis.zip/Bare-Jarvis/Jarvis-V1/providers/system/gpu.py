from __future__ import annotations

import shutil
import subprocess

def get_gpu_info() -> dict:
    if shutil.which("nvidia-smi"):
        try:
            output = subprocess.check_output(
                [
                    "nvidia-smi",
                    "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
                    "--format=csv,noheader,nounits",
                ],
                text=True,
                timeout=5,
            ).strip()
            gpus = []
            for line in output.splitlines():
                name, util, mem_used, mem_total, temp = [x.strip() for x in line.split(",")]
                gpus.append({
                    "name": name,
                    "utilization_percent": int(util),
                    "memory_used_mb": int(mem_used),
                    "memory_total_mb": int(mem_total),
                    "temperature_c": int(temp),
                })
            return {"available": True, "vendor": "nvidia", "devices": gpus}
        except Exception as exc:
            return {"available": False, "error": f"nvidia-smi failed: {exc}"}
    return {"available": False, "error": "No supported GPU telemetry tool found"}
