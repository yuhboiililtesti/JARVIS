from __future__ import annotations

from providers.system.analyzer import analyze_system
from jarvis.safety.audit import log_audit

def suggest_repairs(report: dict | None = None) -> list[str]:
    report = report or analyze_system()
    suggestions = []

    if report["memory"]["ram_percent"] >= 80:
        top = report.get("top_memory_processes", [])
        if top:
            top_names = ", ".join(p["name"] for p in top[:3])
            suggestions.append(f"Close or restart the heaviest memory users first: {top_names}.")
        else:
            suggestions.append("Close heavy applications or restart background tools using large memory.")
    if report["cpu"]["usage_percent"] >= 80:
        suggestions.append("Inspect the top CPU users and pause unnecessary workloads.")
    if report["disk_health"]["usage_percent"] >= 85:
        suggestions.append("Free disk space by removing temporary files, downloads, or stale logs.")
    if not report["gpu"].get("available", False):
        suggestions.append("GPU telemetry is unavailable. Install vendor tools if GPU monitoring matters to you.")
    if not suggestions:
        suggestions.append("No urgent repair actions suggested.")

    return suggestions

def perform_safe_repairs() -> dict:
    report = analyze_system()
    suggestions = suggest_repairs(report)
    log_audit("repair", "Generated non-destructive repair recommendations")
    return {"report": report, "suggestions": suggestions, "actions_taken": []}
