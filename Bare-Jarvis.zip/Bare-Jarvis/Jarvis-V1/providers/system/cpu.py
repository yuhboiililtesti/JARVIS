from __future__ import annotations
import psutil

def get_cpu_info() -> dict:
    return {
        "usage_percent": psutil.cpu_percent(interval=0.2),
        "core_count_logical": psutil.cpu_count(logical=True),
        "core_count_physical": psutil.cpu_count(logical=False),
        "load_avg": getattr(psutil, "getloadavg", lambda: None)(),
    }
