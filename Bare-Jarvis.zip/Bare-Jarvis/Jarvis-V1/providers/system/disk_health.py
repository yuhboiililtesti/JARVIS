from __future__ import annotations

import shutil
from pathlib import Path

def get_disk_health() -> dict:
    root_path = Path.cwd().anchor or "/"
    total, used, free = shutil.disk_usage(root_path)
    usage_percent = round((used / total) * 100, 2) if total else 0.0
    level = "healthy"
    if usage_percent >= 95:
        level = "critical"
    elif usage_percent >= 85:
        level = "high"
    elif usage_percent >= 75:
        level = "moderate"
    return {
        "total": total,
        "used": used,
        "free": free,
        "usage_percent": usage_percent,
        "level": level,
        "smart_note": "Native SMART parsing is not bundled in this offline build. Use CrystalDiskInfo or smartctl for drive-level SMART details."
    }
