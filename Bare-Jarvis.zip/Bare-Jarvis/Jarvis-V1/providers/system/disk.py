from __future__ import annotations
import psutil
from pathlib import Path

def get_disk_info() -> dict:
    root_path = Path.cwd().anchor or "/"
    usage = psutil.disk_usage(root_path)
    partitions = []
    for p in psutil.disk_partitions(all=False):
        partitions.append({
            "device": p.device,
            "mountpoint": p.mountpoint,
            "fstype": p.fstype,
            "opts": p.opts,
        })
    return {
        "usage_total": usage.total,
        "usage_used": usage.used,
        "usage_free": usage.free,
        "usage_percent": usage.percent,
        "partitions": partitions,
    }
