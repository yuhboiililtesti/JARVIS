from __future__ import annotations

from providers.system.cpu import get_cpu_info
from providers.system.memory import get_memory_info
from providers.system.disk import get_disk_info
from providers.system.disk_health import get_disk_health
from providers.system.gpu import get_gpu_info
from providers.system.network import get_network_info
from providers.system.processes import top_processes_by_memory

def analyze_system() -> dict:
    cpu = get_cpu_info()
    memory = get_memory_info()
    disk = get_disk_info()
    disk_health = get_disk_health()
    gpu = get_gpu_info()
    network = get_network_info()
    processes = top_processes_by_memory(5)

    findings = []
    risk = "low"

    if memory["ram_percent"] >= 90:
        findings.append("RAM usage is critical.")
        risk = "high"
    elif memory["ram_percent"] >= 80:
        findings.append("RAM usage is elevated.")
        risk = "medium"

    if cpu["usage_percent"] >= 95:
        findings.append("CPU usage is critical.")
        risk = "high"
    elif cpu["usage_percent"] >= 80 and risk != "high":
        findings.append("CPU usage is elevated.")
        risk = "medium"

    if disk_health["usage_percent"] >= 95:
        findings.append("Disk usage is critical.")
        risk = "high"
    elif disk_health["usage_percent"] >= 85 and risk == "low":
        findings.append("Disk usage is elevated.")
        risk = "medium"

    return {
        "risk": risk,
        "findings": findings,
        "cpu": cpu,
        "memory": memory,
        "disk": disk,
        "disk_health": disk_health,
        "gpu": gpu,
        "network": network,
        "top_memory_processes": processes,
    }
