from __future__ import annotations
import psutil

def get_network_info() -> dict:
    io = psutil.net_io_counters()
    stats = psutil.net_if_stats()
    addrs = psutil.net_if_addrs()
    return {
        "bytes_sent": io.bytes_sent,
        "bytes_recv": io.bytes_recv,
        "interfaces": {
            name: {
                "isup": stat.isup,
                "speed": stat.speed,
                "mtu": stat.mtu,
                "addresses": [a.address for a in addrs.get(name, [])],
            }
            for name, stat in stats.items()
        },
    }
