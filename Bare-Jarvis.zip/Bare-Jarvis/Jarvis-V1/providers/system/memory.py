from __future__ import annotations
import psutil

def get_memory_info() -> dict:
    vm = psutil.virtual_memory()
    sm = psutil.swap_memory()
    return {
        "ram_total": vm.total,
        "ram_available": vm.available,
        "ram_used": vm.used,
        "ram_percent": vm.percent,
        "swap_total": sm.total,
        "swap_used": sm.used,
        "swap_percent": sm.percent,
    }
