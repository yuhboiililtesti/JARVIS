from __future__ import annotations

import requests
from jarvis.config import load_config

def check_ollama_health() -> tuple[bool, str]:
    cfg = load_config()
    base_url = cfg["ollama"]["base_url"].rstrip("/")
    try:
        response = requests.get(f"{base_url}/api/tags", timeout=5)
        response.raise_for_status()
        return True, "ok"
    except Exception as exc:
        return False, str(exc)
