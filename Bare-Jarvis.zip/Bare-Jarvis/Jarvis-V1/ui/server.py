from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from api.routes.ask import router as ask_router
from jarvis.runtime import boot

boot()
app = FastAPI(title="J.A.R.V.I.S Dashboard")
app.include_router(ask_router, prefix="/api")
app.mount("/", StaticFiles(directory="ui/static", html=True), name="ui")
