const boardEl = document.getElementById("board");
const statusEl = document.getElementById("statusText");
const turnEl = document.getElementById("turnText");
const lastMoveEl = document.getElementById("lastMoveText");
const resetBtn = document.getElementById("resetBtn");
const speakBtn = document.getElementById("speakBtn");

const pieces = {
  "P": "♙", "N": "♘", "B": "♗", "R": "♖", "Q": "♕", "K": "♔",
  "p": "♟", "n": "♞", "b": "♝", "r": "♜", "q": "♛", "k": "♚"
};

let selected = null;
let legalMoves = [];
let fen = null;

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = 1.12;
  utter.pitch = 0.95;
  window.speechSynthesis.speak(utter);
}

function squareName(row, col) {
  return "abcdefgh"[col] + (8 - row);
}

function parseFenBoard(fen) {
  const placement = fen.split(" ")[0];
  const rows = placement.split("/");
  const grid = [];
  for (const row of rows) {
    const cells = [];
    for (const ch of row) {
      if ("12345678".includes(ch)) {
        for (let i = 0; i < Number(ch); i++) cells.push("");
      } else {
        cells.push(ch);
      }
    }
    grid.push(cells);
  }
  return grid;
}

function renderBoard(state) {
  fen = state.fen;
  legalMoves = state.legal_moves || [];
  const grid = parseFenBoard(state.fen);
  boardEl.innerHTML = "";

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const sq = squareName(r, c);
      const div = document.createElement("div");
      div.className = `square ${(r + c) % 2 === 0 ? "light" : "dark"}`;
      if (selected === sq) div.classList.add("selected");
      if (selected && legalMoves.some(m => m.startsWith(selected) && m.slice(2,4) === sq)) {
        div.classList.add("target");
      }
      div.dataset.square = sq;
      div.textContent = pieces[grid[r][c]] || "";
      div.addEventListener("click", onSquareClick);
      boardEl.appendChild(div);
    }
  }

  statusEl.textContent = `Game status: ${state.status}`;
  turnEl.textContent = `Turn: ${state.turn}`;
  lastMoveEl.textContent = `Last move: ${state.last_move || "none"}`;
}

async function fetchState() {
  const res = await fetch("/api/chess/state");
  const state = await res.json();
  renderBoard(state);
}

async function makeMove(move) {
  const res = await fetch("/api/chess/move", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({move})
  });
  const data = await res.json();
  if (!data.ok) {
    statusEl.textContent = data.error || "Move failed.";
    return;
  }
  selected = null;
  renderBoard(data.state);
  if (data.state.jarvis_move) {
    speak(`My move is ${data.state.jarvis_move}`);
  }
}

function onSquareClick(event) {
  const sq = event.currentTarget.dataset.square;
  if (!selected) {
    selected = sq;
    renderBoard({fen, legal_moves: legalMoves, status: statusEl.textContent.replace("Game status: ",""), turn: turnEl.textContent.replace("Turn: ",""), last_move: lastMoveEl.textContent.replace("Last move: ","")});
    return;
  }

  if (selected === sq) {
    selected = null;
    renderBoard({fen, legal_moves: legalMoves, status: statusEl.textContent.replace("Game status: ",""), turn: turnEl.textContent.replace("Turn: ",""), last_move: lastMoveEl.textContent.replace("Last move: ","")});
    return;
  }

  const move = selected + sq;
  makeMove(move);
}

resetBtn.addEventListener("click", async () => {
  const res = await fetch("/api/chess/reset", {method: "POST"});
  const state = await res.json();
  selected = null;
  renderBoard(state);
});

speakBtn.addEventListener("click", () => {
  speak(`${statusEl.textContent}. ${turnEl.textContent}. ${lastMoveEl.textContent}.`);
});

fetchState();
