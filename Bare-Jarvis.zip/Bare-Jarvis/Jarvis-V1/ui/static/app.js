const QUICK_COMMANDS = [
  "Jarvis how's the system",
  "Jarvis what's using memory",
  "Jarvis any alerts",
  "Jarvis fix the system",
  "Jarvis system status",
  "Jarvis analyze system",
  "Jarvis what is slowing the system",
  "Jarvis show heavy processes",
  "Jarvis what needs attention",
  "Jarvis repair suggestions",

  "Jarvis CPU status",
  "Jarvis memory status",
  "Jarvis disk status",
  "Jarvis network status",
  "Jarvis GPU status",
  "Jarvis uptime status",
  "Jarvis summarize system health",
  "Jarvis explain current risk",
  "Jarvis is the system okay",
  "Jarvis check performance",

  "Jarvis top memory processes",
  "Jarvis top CPU processes",
  "Jarvis why is memory high",
  "Jarvis why is the system slow",
  "Jarvis what should I close",
  "Jarvis what should I fix first",
  "Jarvis cleanup advice",
  "Jarvis optimize performance",
  "Jarvis quick health check",
  "Jarvis detailed health check",

  "Jarvis recent alerts",
  "Jarvis active alerts",
  "Jarvis clear explanation of alerts",
  "Jarvis what changed recently",
  "Jarvis learning status",
  "Jarvis audit log summary",
  "Jarvis voice status",
  "Jarvis browser mic status",
  "Jarvis speak system status",
  "Jarvis speak alerts",

  "Jarvis sandbox this code",
  "Jarvis simulate this code",
  "Jarvis test this Python code",
  "Jarvis verify this script",
  "Jarvis review this code",
  "Jarvis explain this code",
  "Jarvis make a new module",
  "Jarvis create a helper module",
  "Jarvis chess status",
  "Jarvis reset chess game"
];

function appendMessage(role, text) {
  const stream = document.getElementById("chatStream");
  const wrap = document.createElement("div");
  wrap.className = `message ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  wrap.appendChild(bubble);
  stream.appendChild(wrap);
  stream.scrollTop = stream.scrollHeight;
}

function speakBrowser(text) {
  const toggle = document.getElementById("speechToggle");
  if (!toggle || !toggle.checked) return;
  if (!("speechSynthesis" in window)) return;

  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = 1.12;
  utter.pitch = 0.95;

  const voices = window.speechSynthesis.getVoices();
  const british = voices.find(v => {
    const s = `${v.name} ${v.lang}`.toLowerCase();
    return s.includes("en-gb") || s.includes("british") || s.includes("hazel");
  });
  if (british) utter.voice = british;
  window.speechSynthesis.speak(utter);
}

async function askJarvis(prompt) {
  appendMessage("user", prompt);
  const res = await fetch("/api/ask", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({prompt})
  });
  const data = await res.json();
  const response = data.response ?? "No response.";
  appendMessage("assistant", response);
  speakBrowser(response);
}

function renderList(elementId, items, renderer, emptyText="Nothing to show.") {
  const el = document.getElementById(elementId);
  el.innerHTML = "";
  if (!items || items.length === 0) {
    const item = document.createElement("div");
    item.className = "item";
    item.textContent = emptyText;
    el.appendChild(item);
    return;
  }
  items.forEach(item => el.appendChild(renderer(item)));
}

function alertCard(alert) {
  const div = document.createElement("div");
  div.className = `item ${alert.level || ""}`;
  div.innerHTML = `
    <div class="item-title">${alert.title}</div>
    <div>${alert.details}</div>
    <div class="item-subtle">${alert.created_at}</div>
  `;
  return div;
}

function processCard(proc) {
  const div = document.createElement("div");
  div.className = "item";
  div.innerHTML = `
    <div class="item-title">${proc.name}</div>
    <div>Memory: ${proc.memory_percent}%</div>
    <div class="item-subtle">PID ${proc.pid} · CPU ${proc.cpu_percent}%</div>
  `;
  return div;
}

function repairCard(text) {
  const div = document.createElement("div");
  div.className = "item";
  div.innerHTML = `<div>${text}</div>`;
  return div;
}

function learningCard(row) {
  const div = document.createElement("div");
  div.className = "item";
  div.innerHTML = `
    <div class="item-title">${row.action}</div>
    <div>Score ${row.score}</div>
    <div class="item-subtle">Success ${row.success_count} · Failures ${row.failure_count}</div>
  `;
  return div;
}

function renderCommandGrid() {
  const grid = document.getElementById("commandGrid");
  grid.innerHTML = "";
  QUICK_COMMANDS.forEach(cmd => {
    const btn = document.createElement("button");
    btn.className = "command-btn";
    btn.textContent = cmd.replace(/^Jarvis\s*/i, "");
    btn.addEventListener("click", async () => {
      await askJarvis(cmd);
    });
    grid.appendChild(btn);
  });
}

async function refreshVoiceStatus() {
  try {
    const res = await fetch("/api/voice-status");
    const data = await res.json();
    const webMic = ("webkitSpeechRecognition" in window) || ("SpeechRecognition" in window);
    document.getElementById("voiceStatusText").textContent =
      data.mic_available ? "Python mic ready" : (webMic ? "Browser mic available" : "Voice input limited");
    document.getElementById("voiceStatusDetail").textContent =
      data.mic_available
        ? `Preferred voice: ${data.preferred_voice || "default"}`
        : (webMic
            ? "Local Python mic backend is unavailable, but browser speech recognition can be used."
            : `Python mic unavailable: ${data.mic_reason || "unknown error"}`);
  } catch (err) {
    document.getElementById("voiceStatusText").textContent = "Voice check failed";
    document.getElementById("voiceStatusDetail").textContent = String(err);
  }
}

async function refreshAll() {
  const [metricsRes, repairRes, learningRes, alertsRes] = await Promise.all([
    fetch("/api/metrics"),
    fetch("/api/repair"),
    fetch("/api/learning"),
    fetch("/api/alerts")
  ]);

  const metrics = await metricsRes.json();
  const repair = await repairRes.json();
  const learning = await learningRes.json();
  const alerts = await alertsRes.json();

  document.getElementById("riskValue").textContent = (metrics.risk || "--").toUpperCase();
  document.getElementById("riskDetail").textContent = (metrics.findings && metrics.findings.length) ? metrics.findings[0] : "No urgent findings";
  document.getElementById("cpuValue").textContent = `${metrics.cpu?.usage_percent ?? "--"}%`;
  document.getElementById("memoryValue").textContent = `${metrics.memory?.ram_percent ?? "--"}%`;
  document.getElementById("diskValue").textContent = `${metrics.disk_health?.usage_percent ?? "--"}%`;

  renderList("alertsList", alerts.alerts || [], alertCard, "No active alerts.");
  renderList("processList", metrics.top_memory_processes || [], processCard, "No heavy processes detected.");
  renderList("repairList", repair.suggestions || [], repairCard, "No repairs suggested.");
  renderList("learningList", learning.top_actions || [], learningCard, "No learned actions yet.");

  const hasAlerts = (alerts.alerts || []).length > 0;
  document.getElementById("statusText").textContent = hasAlerts ? "Attention needed" : "Monitoring online";
  document.getElementById("statusDetail").textContent = hasAlerts
    ? `${alerts.alerts.length} active alert(s) detected.`
    : "No active alerts. Telemetry looks stable.";

  await refreshVoiceStatus();
}

function startBrowserMic() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    appendMessage("assistant", "Browser speech recognition is not available in this browser.");
    return;
  }
  const rec = new SR();
  rec.lang = "en-US";
  rec.interimResults = false;
  rec.maxAlternatives = 1;

  appendMessage("assistant", "Listening through browser mic...");
  rec.onresult = async (event) => {
    const text = event.results[0][0].transcript;
    await askJarvis(text);
  };
  rec.onerror = (event) => {
    appendMessage("assistant", `Browser mic error: ${event.error}`);
  };
  rec.start();
}

document.getElementById("sendBtn").addEventListener("click", async () => {
  const input = document.getElementById("prompt");
  const prompt = input.value.trim();
  if (!prompt) return;
  input.value = "";
  await askJarvis(prompt);
});

document.getElementById("prompt").addEventListener("keydown", async (e) => {
  if (e.key === "Enter") {
    const input = document.getElementById("prompt");
    const prompt = input.value.trim();
    if (!prompt) return;
    input.value = "";
    await askJarvis(prompt);
  }
});

document.getElementById("micBtn").addEventListener("click", startBrowserMic);
document.getElementById("gameBtn").addEventListener("click", () => {
  window.open("/chess.html", "_blank");
});

document.getElementById("commandMenuBtn").addEventListener("click", () => {
  document.getElementById("commandDropdown").classList.toggle("hidden");
});

document.getElementById("closeCommandMenu").addEventListener("click", () => {
  document.getElementById("commandDropdown").classList.add("hidden");
});

renderCommandGrid();
refreshAll();
setInterval(refreshAll, 5000);
