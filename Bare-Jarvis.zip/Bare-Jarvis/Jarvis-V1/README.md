# JARVIS v1

JARVIS v1 is a local AI assistant prototype that combines a web UI, local LLM integration through Ollama, basic voice interaction, system telemetry, memory logging, and early command routing in one modular Python project.

This repository is a foundation, not a finished autonomous assistant.

## Current capabilities
- FastAPI backend and browser dashboard
- Local chat through Ollama
- Basic speech input/output pipeline
- Simple wake-word text matching using `jarvis`
- CPU, memory, disk, network, and limited GPU telemetry
- SQLite-backed memory and audit logging
- Early automation, safety, and sandbox scaffolding

## Current limitations
- Wake word is not a true always-listening engine
- Voice reliability is inconsistent across platforms
- Operating-system control is limited
- Intent routing is still largely keyword-based
- Security boundaries are prototype-level
- Test coverage is minimal

## Platform status
- Windows: partial support
- Linux: partial support

Cross-platform support is still experimental.

## Quick start
```bash
python -m pip install -r requirements.txt
ollama serve
python run_ui.py
```

Open `http://127.0.0.1:8000`

## CLI mode
```bash
python main.py
```

## Configuration
1. Copy `config/app.example.json` to `config/app.json`
2. Adjust local values as needed
3. Keep `config/app.json` out of version control

Optional:
- Copy `.env.example` to `.env`
- Enable voice features only after confirming local audio dependencies work on your OS

## Repository layout
```text
api/            FastAPI routes and schemas
jarvis/         Core assistant modules
providers/      System and Ollama provider integrations
ui/             Static dashboard assets and web server
voice/          Prototype voice pipeline
scripts/        Bootstrap and diagnostic helpers
tests/          Automated tests
config/         Example and local configuration
```

## Public repo notes
Before publishing or forking:
- do not commit `config/app.json`
- do not commit `.env`
- do not commit `data/*.db`, logs, or cache files
- review the publishing checklist in `docs/PUBLISHING_CHECKLIST.md`

## License
MIT
