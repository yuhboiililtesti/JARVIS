# Security Policy

## Supported Status
This repository is currently a prototype and should not be treated as production-hardened.

## Reporting a Vulnerability
Do not open a public issue for security-sensitive problems.

Instead, report:
- affected files or components
- reproduction steps
- impact assessment
- suggested mitigation if known

Until a dedicated private contact is added, avoid publishing exploit details before a fix is available.

## Current Security Caveats
- Voice and command features are experimental
- Sandbox boundaries are limited
- Platform control features should be treated as high risk until permissioning is improved
