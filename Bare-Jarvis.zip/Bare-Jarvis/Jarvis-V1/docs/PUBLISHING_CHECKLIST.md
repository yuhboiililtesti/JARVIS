# Publishing Checklist

## Before first public push
- [ ] Replace `config/app.json` with a local-only version
- [ ] Keep `config/app.example.json` sanitized
- [ ] Review commit history for secrets or personal data
- [ ] Run tests
- [ ] Verify README matches actual behavior
- [ ] Confirm license choice
- [ ] Decide whether to keep the `JARVIS` name publicly

## Recommended pre-push checks
```bash
git status
pytest
python -m compileall .
git grep -nEi "api[_-]?key|token|secret|password|private[_-]?key|bearer|sk-|ghp_|AIza"
```
